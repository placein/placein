'use strict';

var o = require('./../gulp/config.json');
var gulp = require('gulp');
var autoprefixer = require('gulp-autoprefixer');
var cached = require('gulp-cached');
var combineMediaQueries = require('gulp-combine-media-queries');
var csso = require('gulp-csso');
var header = require('gulp-header');
var pkg = require('./../package.json');
var rename = require('gulp-rename');
var sass = require('gulp-sass');
var scssLint = require('gulp-scss-lint');
var sourcemaps = require('gulp-sourcemaps');
var stripCssComments = require('gulp-strip-css-comments');

gulp.task('sass', ['sass:lint', 'sass:compile', 'sass:minify']);

gulp.task('sass:lint', function () {
    return gulp.src(o.sass.input + '*.scss')
        .pipe(cached('scssLint'))
        .pipe(scssLint({
            'config': o.sass.linter,
            'reporterOutput': o.sass.lintReport,
        }));
});

gulp.task('sass:compile', function () {
    return gulp.src(o.sass.input + '*.scss')
        .pipe(sourcemaps.init())
        .pipe(sass({
            errLogToConsole: o.sass.log,
        }).on('error', sass.logError))
        .pipe(autoprefixer(o.sass.support))
        .pipe(sourcemaps.write())
        // .pipe(header(banner, { pkg : pkg }))
        .pipe(gulp.dest(o.sass.output));
});

gulp.task('sass:minify', function () {
    return gulp.src([o.sass.output + '*.css', '!' + o.sass.output + '*.min.css'])
        // .pipe(combineMediaQueries())
        .pipe(stripCssComments({
            preserve: false
        }))
        .pipe(csso())
        .pipe(rename({
            suffix: '.min'
        }))
        .pipe(gulp.dest(o.sass.output));
});
